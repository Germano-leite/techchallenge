package com.techchallenge.repository;

import com.techchallenge.model.Contratacao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContratacaoRepository extends JpaRepository<Contratacao, Long> {
}

