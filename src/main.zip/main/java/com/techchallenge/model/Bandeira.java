package com.techchallenge.model;

public enum Bandeira {
    VISA,
    MASTERCARD,
    ELO,
    AMEX,
    HIPERCARD
}
