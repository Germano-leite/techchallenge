package com.techchallenge.model;

public enum StatusContratacao {
    ATIVO,
    CANCELADO
}
