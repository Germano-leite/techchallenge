package com.techchallenge.model;

public enum TipoCartao {
    CREDITO,
    DEBITO
}
